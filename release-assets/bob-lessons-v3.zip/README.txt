Bob's lesson sets, v3 (7 November 2026)

16 folders, 9,059 lessons, written by Qwen3.6-35B-A3B playing Bob (Bob's real system prompt and tool list),
used to heal 28Bob Riker v3 and planned for 20Bob Bill v3. See docs/FORGE-JOURNAL.md in the Bob repository.

Each folder: lessons.jsonl (one lesson per line: idea id, job, thinking on/off, the messages) and toolsets.json
(which tools that lesson could see). The folder "lessons" is the base set; the others are the extra sets the
Forge merges with ids prefixed "x<n>-" (plans/bill-v3.json lists them in order).

This public copy differs from the files the Bobs were trained on in one way: the owner's machine details that the
model picked up from Bob's prompt (a Windows user folder, home network addresses, e-mail addresses, a projects
folder name) were replaced with neutral stand-ins (C:\Users\you, 192.168.0.10, you@example.com, Projects). Nothing
else was changed. Licence: see the release notes.
